#include <MultMatrix.hh>

/////////////////////////////////////////////////////////////////////////////////
//  Identificación del alumno
//
//  Nombre Completo: Alejandro Javier Oliveros Vera
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
//
//   Description:
//      En este archivo se encuentra la implementación de las funciones de
//	multiplicacion de matrices, el primer metodo (ijk) es el convencional
//	y el segundo (kij) es el que tiene en cuenta el uso de memoria cache.
//
/////////////////////////////////////////////////////////////////////////////////



void MultMatrix::DOijk(Matrix<float>& A, Matrix<float>& B, Matrix<float>& C)
{
	if (A.rows() == B.cols() && A.cols() == B.rows()){

		for(size_t i=0; i < A.rows(); i++){
			for(size_t j=0; j < B.cols(); j++){
				for(size_t k=0; k < A.cols(); k++){
					C.value(i,j,C.value(i,j)+(A.value(i,k) * B.value(k,j)));
				}
			}
		}

		/*for (size_t i=0; i<C.rows(); i++){
			std::cout << "\n";
			for (size_t j=0; j<C.cols(); j++){
				std::cout << C.value(i,j) << " ";
			}
		}
		std::cout << "\n";*/

	}else std::cout << "La matriz debe ser cuadrada para poder multiplicarla por si misma\n";
}


void MultMatrix::DOkij(Matrix<float>& A,Matrix<float>& B, Matrix<float>& C)
{
	//Completar
	if (A.rows() == B.cols() && A.cols() == B.rows()){

		for(size_t k=0; k < A.cols(); k++){
			for(size_t i=0; i < A.rows(); i++){
				float r = A.value(i,k);
				for(size_t j=0; j < B.cols(); j++){
					C.value(i,j, C.value(i,j)+(r*B.value(k,j)));
				}
			}
		}

		/*for (size_t i=0; i<C.rows(); i++){
			std::cout << "\n";
			for (size_t j=0; j<C.cols(); j++){
				std::cout << " " << C.value(i,j);
			}
		}*/
	}else std::cout << "La matriz debe ser cuadrada para poder multiplicarla por si misma\n";

}

